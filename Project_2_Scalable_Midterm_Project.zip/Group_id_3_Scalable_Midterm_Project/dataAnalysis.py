"""
This Package include all the grouping data function as well as the plotly graph functions.
"""

import pandas as pd
import seaborn as sns
import plotly.express as px
import matplotlib.pyplot as plt
from plotly.subplots import make_subplots
import plotly.graph_objects as go


class dataAnalysis:
    
    def get_highest_happiness_score_by_year(df,col_lst,by_col,year,num_rows):
        """
        Function to get the highest unemployment rate by major.
        """
        df = df[df['Year'] == year]
        return df[col_lst].sort_values(by=by_col,ascending=False)[:num_rows]
    
    # add color in argument 
    def get_plotly_bar_graph(*args):
        """
        Function to create the Vertical Bar chart using plotly library. 
        """
        fig = px.bar(args[0], x=args[1], y=args[2],
                 hover_data=args[3],color=arg[4],title=args[5])

        return fig.show()
    
           
    def get_plotly_boxplot(df,cols):
        """
        Function to create the boxplot graph using plotly library. 
        """
        fig = make_subplots(rows=1, cols=len(cols))
        for i, col in enumerate(cols):
            fig.add_trace(go.Box(y=df[col],name=col),row=1, col=i+1)

        fig.update_traces(boxpoints='all', jitter=.3)
        return fig.show()
    
    def get_seaborn_heatmap(df):
        """
        Function to create the heatmap using seaborn library.
        """
        fig, ax = plt.subplots(figsize=(20, 8))
        corr = df.corr()
        sns.heatmap(corr, 
                    xticklabels=corr.columns.values,
                    yticklabels=corr.columns.values,
                       annot=True)
        return plt.show()
   
    
    def get_plotly_scatter_plot(df,col_x,col_y,marginal_type):
        """
        Function to create the scatter plot using using plotly library. 
        """
        fig = px.scatter(df, x=col_x, y=col_y,marginal_x=marginal_type,marginal_y=marginal_type)
        return fig.show()
    
    def get_plotly_bar_graph(grouping_df,col_X,col_Y,graph_title,color=None,barmode=None):
        """
        Function to create the bar chart using plotly library. 
        """
        fig = px.bar(grouping_df, x=col_X, y=col_Y,color=color,title=graph_title,barmode=barmode)
        return fig.show()
    

    def get_plotly_pie_chart(grouping_df,names,values,color,hover_col_lst,graph_title):
        """
        Function to create the pie chart using plotly library. 
        """
        fig = px.pie(grouping_df, names= names,values=values, color = color,
             hover_data=hover_col_lst,title=graph_title)
        return fig.show()

  
    def get_pairplot(df,cols):
        """
        Function to create the pairplot of features of dataset.
        """
        plt.figure(figsize=(20,8))
        sns.pairplot(df,x_vars=cols,y_vars=cols);
        