"""
This Package include all the functions of data cleaning. 

"""

import csv
import pandas as pd

class dataCleaning:
    
    def readFile(filepath):
        """
        Function to Read file and it returns the dataframe.
        """
        try:
            df = pd.read_csv(filepath)
            return df
        except FileNotFoundError:
            print(f"No such file found on this path : {filepath}")
    
   
    def slice_data(indx, *collectn):
        """
        Use of exception handling and *args which shows index error if you put wronge index value
        """
        try:
            print("Value at index : {} = {}".format(indx, collectn[indx]))
        except IndexError:
            print("IndexError Occurred")
           
    
    def find_outliers(df,feature):
        """
        Function to check outlier using IQR method
        Returns row index of outlier
        """
        #Get first quartile 
        Q1 = df[feature].quantile(0.25)
        #Get third quartile 
        Q3 = df[feature].quantile(0.75)   
        IQR = Q3 - Q1
        #find lower bound by using formula
        lower_bound = Q1 - IQR * 1.5
         #find upper bound
        upper_bound = Q3 + IQR * 1.5
        # find out the row indices having outliers (values less than lower bound and greater than upper bound)
        row_indices = df.index[ (df[feature] < lower_bound) | (df[feature] > upper_bound) ]
        return row_indices
    
    def checkAnyNullValues(df):
        """
        Function to Check any null values in df, it returns the sum of null values of df.
        """
        count_null = df.isnull().sum()
        return count_null
   
    def get_larget(count, data, feature):
        """
        Function to get larget records according to passed feature value and count
        """
        data = data.sort_values(by=[feature])
        return data.head(count)
    
   

    
    