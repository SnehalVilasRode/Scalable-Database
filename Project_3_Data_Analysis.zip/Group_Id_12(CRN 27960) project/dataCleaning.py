"""
This Package include all the functions of data cleaning. 

"""

import csv
import pandas as pd

class dataCleaning:
    
    def readFile(filepath):
        """
        Function to Read file and it returns the dataframe.
        """
        try:
            df = pd.read_csv(filepath)
            return df
        except FileNotFoundError:
            print(f"No such file found on this path : {filepath}")
    
    def get_feature_names(df,filepath):
        """
        Function to get all the feature(column) names of the dataframe.
        """
        try:
            with open(filepath, "r") as f:
                dataset_csv = csv.reader(f)
                headers = next(dataset_csv)
            return headers  
        except FileNotFoundError:
            print(f"No such file found on this path : {filepath}")

    def get_datatype_of_df_cols(df):
        """
        Function to get the each column datatype.
        """
        return df.dtypes
    
    def matrix_represenation(df):
        """
        Function of Matrix Representation of df.
        """
        return df.values
    
    def matrix_represenation_using_numpy(df):
        """
        Function of Numpy Matrix Representation of df.
        """
        return df.to_numpy()
    
    def checkAnyNullValues(df):
        """
        Function to Check any null values in df, it returns the sum of null values of df.
        """
        count_null = df.isnull().sum()
        return count_null
    
    def checkNullValuesInColumn(df,column):
        """
        Function to get Null Values Column.
        """
        return df[df[column].isnull()==True]
    
    def dropNanValue(df):
        """ 
        Function to drop the NaN values of the dataframe.
        """
        return df.dropna()
    
    def dropDuplicateValue(df):
        """
        Function to drop duplicate rows of the dataframe.
        """
        return df.drop_duplicates()
    
    def dropColumn(df,column_lst):
        """
        Function to drop the unwanted column of the dataframe.
        """
        return df.drop(column_lst,axis=1,inplace=True)
    
    def getNumRowsNumCols(df):
        """
        Function to get the count of rows and columns of the dataframe.
        """
        return df.shape
    
    def quickViewOfDataset(df,num_of_rows):
        """
        Function to get the quick view of dataset.
        """
        return df.head(num_of_rows)
    
    def get_col_based_on_datatype(df,col_datatype_lst):
        """
        Function to get column names based on its datatype. 
        """
        return df.select_dtypes(include=col_datatype_lst).columns
    
    def get_statistical_description(df): 
        """
        Function to get the summary of numerical columns of the dataframe.
        """
        return df.describe().T
    
    def getUniqueColValues(df,column):
        """"
        Function to get the Unique Values of particular coloumn of the dataframe.
        """
        return df[column].unique()
    
    